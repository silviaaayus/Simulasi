<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ServerApi extends CI_Controller {

    
    // fungsi untuk CREATE
    // public function addStaff()
    // {
        // RESPONSE API ADALAH BENTUK JSON YANG AKAN DIOPER KE KLIEN ATAU ANDROID ATAU YANG LAINNYA
        // $respons_api = array();

        // PENAMPUNG DATA YANG AKAN DIMASUKAN KEDALAM DATABASE
        // $data = array();

        // MENANGKAP DATA DARI USER ATAU ANDROID ATAU CLIENT
        // nama ADALAH NAMA KOLOM DIDATABASE. JADI SESUAIKAN
        // $data['nama'] = $this->input->post('nama'); 

        // VARIABEL $DATA DIMASUKAN KEDALAM DATABASE
        // tb_staff = NAMA TABEL DIDATABASE
        // $proses_simpan_data = $this->db->insert('tb_staff', $data);
        
        // PROSES PENGECEKAN APAKAH PROSES INSERT KEDATABAE BERHASIL ATAU TIDAK
        // JIKA PROSES SIMPAN DATA BERHASIL, MAKA JALANKAN KODE DIBAWAH
        // if ($proses_simpan_data) 
        // {
        //     $respons_api['message'] = 'insert berhasil';
        //     $respons_api['status'] = 200; // 200 = BERHASIL
        // }
        // JJIKA TIDAK BERHASIL, MAKA JALANKAN KODE DIBAWAH
        // else 
        // {
        //     $respons_api['message'] = 'insert error';
        //     $respons_api['status'] = 503;
        // }

        // DAFTAR KODE ERROR ATAU HTTP RESPONSE CODE :
        // 200 = OK
        // 204 = OK TAPI DATA KOSONG
        // 401 = NOT ALLOWED ALIAS BELUM LOGIN
        // 403 = FORBIDEN ALIAS DILARANG
        // 404 = NOT FOUND
        // 422 = DATA YANG DIKIRIM OLEH ANDROID TIDAK VALID ALIAS TIDAK SESUAI
        // 503 = TERJADI ERROR PADA PROGRAM ATAU KODING DI BACKEND

        // VARIABEL $respons_api DIOPER KE ANDROID DALAM BENTUK JSON MENGGUNAKAN json_encode
    //     echo json_encode($respons_api);
    // }
      // fungsi untuk READ
  public function getDataMateri()
    {
        header('Content-Type: application/json');
        $response = array();
          $q = $this->db->get('tb_materi');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'data ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'data tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }
    
    public function getDataRpp()
    {
        header('Content-Type: application/json');
        $response = array();
          $q = $this->db->get('tb_rpp');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'data ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'data tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }

    public function getDataVideo()
    {
        header('Content-Type: application/json');
        $response = array();
          $q = $this->db->get('tb_video');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'video ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'video tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }

    public function getDataSoal()
    {   
        header('Content-Type: application/json');
        $response = array();
        $id_materi= $this->input->get('id_materi');
          $q = $this->db->query("SELECT * FROM tb_evaluasi WHERE id_materi='$id_materi'");
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'soal ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'soal tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }

    public function getDataJobsheet()
    {
        $response = array();
          $q = $this->db->get('tb_jobsheet');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'jobsheet ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'jobsheet tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }

    public function getDataSiswa()
    {
        $response = array();
          $q = $this->db->get('tb_siswa');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'siswa ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'siswa tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }

    public function getDataNilai()
    {
        $response = array();
          $q = $this->db->get('tb_nilai');
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'nilai ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'nilai tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }
    
    public function getIdMateri(){
      header('Content-Type: application/json');
      $response = array();
      $id = $this->input->post('id');
      $this->db->select('*');
      $this->db->from('tb_materi');
      $this->db->where('id_materi',$id);  
      $q = $this->db->get();
          if ($q -> num_rows() > 0) {
            $response['pesan'] = 'data ada';
            $response['status'] = 200;
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['pesan'] = 'data tidak ada';
            $response['status'] = 404;
          }
          echo json_encode($response);
    }
    
    public function login()
    {   
        header('Content-Type: application/json');
        $response = array();
        $username           = $this->input->post('username');
        $password           = $this->input->post('password');
          $q = $this->db->query(
              "
                Select * FROM tb_siswa WHERE username = '$username' AND password = '$password'
              ");
          if ($q -> num_rows() > 0) {
            $response['status'] = 1;
            $response['message'] = "Sukses";
            // 1 row
            $response['data'] = $q->row();
            $response['data'] = $q->result();
          } else {
            $response['status'] = 0;
            $response['message'] = "Gagal";
          }
          echo json_encode($response);
    }
    
    public function insert_nilai(){
        header('Content-Type: application/json');
        $response = array();
        $id = $this->input->post('id_siswa');
        $skor = $this->input->post('skor');
        
        $data =array(
            'id_siswa' => $id,
            'skor' => $skor
            );
        
        $save = $this->db->insert('tb_nilai', $data);
        
        if($save){
            $response['status'] = 1;
            $response['message'] = "Sukses";
        }else{
            $response['status'] = 0;
            $response['message'] = "Gagal";
        }
        
         echo json_encode($response);
    }  

     
}